    ymaps.ready(init);

    function init() {
    var geolocation = ymaps.geolocation,
    myMap = new ymaps.Map('map', {
    center: [55, 34],
    zoom: 10
    }, {
    searchControlProvider: 'yandex#search'
    });
    var searchControl = new ymaps.control.SearchControl({
    options: {
    provider: 'yandex#search'
    }
    });
    myMap.controls.add(searchControl);
    searchControl.search('Типография ростов-на-дону');
    }